<?php

use App\Http\Controllers\API\TeamController;
use App\Http\Controllers\API\UserController;
use Illuminate\Support\Facades\Route;

Route::post('login', [UserController::class, 'login']);
Route::post('register', [UserController::class, 'register']);
Route::post('logout', [UserController::class, 'logout'])->middleware('auth:sanctum');
Route::group(['prefix' => 'team', 'middleware' => 'auth:sanctum'], function () {

    Route::get('/', [TeamController::class, 'index']);
    Route::post('add', [TeamController::class, 'add']);
    Route::get('edit/{id}', [TeamController::class, 'edit']);
    Route::post('update/{id}', [TeamController::class, 'update']);
    Route::delete('delete/{id}', [TeamController::class, 'delete']);
});
Route::group(['prefix' => 'player', 'middleware' => 'auth:sanctum'], function () {

    Route::get('/', [PlayerController::class, 'index']);
    Route::post('add', [PlayerController::class, 'add']);
    Route::get('edit/{id}', [PlayerController::class, 'edit']);
    Route::post('update/{id}', [PlayerController::class, 'update']);
    Route::delete('delete/{id}', [PlayerController::class, 'delete']);
});
Route::group(['prefix' => 'trades', 'middleware' => 'auth:sanctum'], function () {

    Route::get('/', [TradeController::class, 'index']);
    Route::get('buy/{id}', [TradeController::class, 'buy']);
    Route::post('updatebuy/{id}', [TradeController::class, 'updatebuy']); 
    Route::get('sell/{id}', [TradeController::class, 'sell']);
    Route::post('updatesell/{id}', [TradeController::class, 'updatesell']);
});
    Route::get('getTeams', 'TeamController@getTeams');
Route::get('getCountries', 'CountryController@getCountries');