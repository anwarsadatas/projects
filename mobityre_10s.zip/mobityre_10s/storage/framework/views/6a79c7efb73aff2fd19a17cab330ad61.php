<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <title><?php echo e(env('APP_NAME')); ?></title>
    <link  type="text/css" rel="stylesheet"/>
    <?php echo app('Illuminate\Foundation\Vite')("resources/css/app.css"); ?>
</head>
<body>
<?php if(Auth::check()): ?>
    <script>
        window.Laravel = <?php echo json_encode([
            'isLoggedin' => true,
            'user' => Auth::user()
        ]); ?>

    </script>
<?php else: ?>
    <script>
        window.Laravel = <?php echo json_encode([
            'isLoggedin' => false
        ]); ?>

    </script>
<?php endif; ?>
<div id="app">
</div>
<script type="text/javascript"></script>
<?php echo app('Illuminate\Foundation\Vite')("resources/js/app.js"); ?>
</body>
</html><?php /**PATH C:\Users\anwar\Desktop\mobityre_10s\resources\views/app.blade.php ENDPATH**/ ?>