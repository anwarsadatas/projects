import {createWebHistory, createRouter} from "vue-router";

import Home from '../pages/Home.vue';
import Register from '../pages/Register.vue';
import Login from '../pages/Login.vue';
import Dashboard from '../pages/Dashboard.vue';
//team vue
import Team from '../components/Team.vue';
import AddTeam from '../components/AddTeam.vue';
import EditTeam from '../components/EditTeam.vue';
//player vue
import Player from '../components/Player.vue';
import AddPlayer from '../components/AddPlayer.vue';
import EditPlayer from '../components/EditPlayer.vue';
//trade players vue definition
import Trades from '../components/Trades.vue';
import BuyPlayer from '../components/BuyPlayer.vue';
import SellPlayer from '../components/SellPlayer.vue';
export const routes = [
    {
        name: 'home',
        path: '/',
        component: Home
    },
    {
        name: 'register',
        path: '/register',
        component: Register
    },
    {
        name: 'login',
        path: '/login',
        component: Login
    },
    {
        name: 'dashboard',
        path: '/dashboard',
        component: Dashboard
    },
    {
        name: 'team',
        path: '/team',
        component: Team
    },
    {
        name: 'addteam',
        path: '/team/add',
        component: AddTeam
    },
    {
        name: 'editteam',
        path: '/team/edit/:id',
        component: EditTeam
    }, {
        name: 'player',
        path: '/player',
        component: Player
    },
    {
        name: 'addplayers',
        path: '/player/add',
        component: AddPlayer
    },
    {
        name: 'editplayer',
        path: '/player/edit/:id',
        component: EditPlayer
    }, 
    {
        name: 'trades',
        path: '/trades',
        component: Trades
    },
    {
        name: 'buy',
        path: '/trades/buy/:id',
        component: BuyPlayer
    },
    {
        name: 'sell',
        path: '/trades/sell/:id',
        component: SellPlayer
    }

];

const router = createRouter({
    history: createWebHistory(),
    routes: routes,
});

export default router;