<template>
    <div>
        <h4 class="text-center">Sell Player</h4>
        <div class="row">
            <div class="col-md-6">
                <form @submit.prevent="updatePlayer">
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" class="form-control" v-model="player.pfsname"   readonly>
                        
                    </div>
                    <div class="form-group">
                        <label>Second Name</label>
                        <input type="text" class="form-control" v-model="player.pscname" readonly>
                    </div> 
                   
                    <div class="form-group">
                        <label>Old Team </label>
                        <input type="text" name="oldteamId" class="form-control" v-model="player.tname" readonly>
                    </div> 

                   
                    <div class="form-group">
                            <label>Select New Team:</label>
                            <select class='form-control' v-model='country' >
                              <option value='0' >Select New Team</option>
                              <option name="newteamId"  v-for='data in teamsl' :value='data.id'>{{ data.tname }}</option>
                            </select>
                        </div>
                    <div class="form-group">
                        <label>Selling Amount</label>
                        <input type="text" name="buyamount" class="form-control" v-model="player.sellamnt" readonly  >
                    </div>

                    <button type="submit" class="btn btn-primary">Sell Player</button>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            player: {},
                state: 0,
                teamsl: []
        }
    },
    created() {
        this.$axios.get('/sanctum/csrf-cookie').then(response => {
            this.$axios.get(`/api/trades/sell/${this.$route.params.id}`)
                .then(response => {
                    this.player = response.data;
                })
                .catch(function (error) {
                    console.error(error);
                });
        })
    },
    methods: {
        updatePlayer() {
            this.$axios.get('/sanctum/csrf-cookie').then(response => {
                this.$axios.post('/api/trades/updatesell/${this.$route.params.id}', this.player)
                    .then(response => {
                        this.$router.push({name: 'trades'});
                    })
                    .catch(function (error) {
                        console.error(error);
                    });
            })
        },
        
            getTeam: function(){
              axios.get('/api/getTeams')
              .then(function (response) {
                 this.teamsl = response.data;
              }.bind(this));
         
            }
    },
    beforeRouteEnter(to, from, next) {
        if (!window.Laravel.isLoggedin) {
            window.location.href = "/";
        }
        next();
    },
    created: function(){
        //    this.getCountries(),
            this.getTeam()
        }
}
</script>