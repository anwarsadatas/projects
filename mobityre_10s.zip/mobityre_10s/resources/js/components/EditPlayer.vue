<template>
    <div>
        <h4 class="text-center">Edit Team</h4>
        <div class="row">
            <div class="col-md-6">
                <form @submit.prevent="updatePlayer">
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" class="form-control" v-model="player.pfsname">

                    </div>
                    <div class="form-group">
                        <label>Second Name</label>
                        <input type="text" class="form-control" v-model="player.pscname">
                    </div> 
                    <div class="form-group">
                            <label>Select Country:</label>
                            <select class='form-control' v-model='country' >
                              <option value='0' >Select Country</option>
                              <option v-for='data in countries' :value='data.id'>{{ data.cntryname }}</option>
                            </select>
                        </div>


                   
                    <div class="form-group">
                            <label>Select Team:</label>
                            <select class='form-control' v-model='team' >
                              <option value='0' >Select Team</option>
                              <option v-for='data in teamsl' :value='data.id'>{{ data.tname }}</option>
                            </select>
                        </div>
                    <div class="form-group">
                        <label>Buying Amount</label>
                        <input type="text" class="form-control" v-model="player.buyamnt">
                    </div><div class="form-group">
                        <label>Selling Amount</label>
                        <input type="text" class="form-control" v-model="player.sellamnt">
                    </div>

                    <button type="submit" class="btn btn-primary">Update Player</button>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            player: {},
                countries: [],
                state: 0,
                teamsl: []
        }
    },
    created() {
        this.$axios.get('/sanctum/csrf-cookie').then(response => {
            this.$axios.get(`/api/player/edit/${this.$route.params.id}`)
                .then(response => {
                    this.player = response.data;
                })
                .catch(function (error) {
                    console.error(error);
                });
        })
    },
    methods: {
        updatePlayer() {
            this.$axios.get('/sanctum/csrf-cookie').then(response => {
                this.$axios.post('/api/player/update/${this.$route.params.id}', this.player)
                    .then(response => {
                        this.$router.push({name: 'player'});
                    })
                    .catch(function (error) {
                        console.error(error);
                    });
            })
        },
        getCountries: function(){
              axios.get('/api/getCountries')
              .then(function (response) {
                 this.countries = response.data;
              }.bind(this));
         
            },
            getTeam: function(){
              axios.get('/api/getTeams')
              .then(function (response) {
                 this.teamsl = response.data;
              }.bind(this));
         
            }
    },
    beforeRouteEnter(to, from, next) {
        if (!window.Laravel.isLoggedin) {
            window.location.href = "/";
        }
        next();
    },
    created: function(){
            this.getCountries(),
            this.getTeam()
        }
}
</script>