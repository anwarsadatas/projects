<template>
    <div>
        <h4 class="text-center">All Team</h4><br/>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Team Name</th>
                <th>Money Balance</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="team in teams" :key="team.id">
                <td>{{ team.id }}</td>
                <td>{{ team.tname }}</td>
                <td>{{ team.money_bal }}</td>
                <td>{{ team.created_at }}</td>
                <td>{{ team.updated_at }}</td>
                <td>
                    <div class="btn-group" role="group">
                        <router-link :to="{name: 'editteam', params: { id: team.id }}" class="btn btn-primary">Edit
                        </router-link>
                        <button class="btn btn-danger" @click="deleteTeam(team.id)">Delete</button>
                    </div>
                </td>
            </tr>
            </tbody>
        </table>
        <Pagination class="mt-6" :links="teams.links" />
        <button type="button" class="btn btn-info" @click="this.$router.push('/teams/add')">Add Team</button>
    </div>
</template>

<script>import axios from 'axios';
export default {

    data() {
        return {
            teams: []
        }
    },
    created() {
        this.$axios.get('/sanctum/csrf-cookie').then(response => {
            this.$axios.get('/api/team')
                .then(response => {
                    console.log(response.data)
                    this.teams = response.data;
                })
                .catch(function (error) {
                    console.error(error);
                });
        })
    },
    methods: {
        deleteTeam(id) {
            this.$axios.get('/sanctum/csrf-cookie').then(response => {
                this.$axios.delete('/api/team/delete/${id}')
                    .then(response => {
                        let i = this.teams.map(item => item.id).indexOf(id); // find index of your object
                        this.teams.splice(i, 1)
                    })
                    .catch(function (error) {
                        console.error(error);
                    });
            })
        }
    },
    beforeRouteEnter(to, from, next) { console.log(window.Laravel.isLoggedin)
        if (!window.Laravel.isLoggedin) {
           // window.location.href = "/";
        }
        next();
    }
}
</script>