<template>
    <div>
        <h4 class="text-center">All Players</h4><br/>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Second Name</th>
                <th>Country</th>
                <th>Team</th>
                <th>Buying Price</th>
                <th>Selling Price</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="player in players" :key="team.id">
                <td>{{ player.id }}</td>
                <td>{{ player.pfsname }}</td>
                <td>{{ player.pscname }}</td>
                <td>{{ player.cntryname }}</td>
                <td>{{ player.tname }}</td>
                <td>{{ player.buyamnt }}</td>
                <td>{{ player.sellamnt }}</td>
                <td>
                    <div class="btn-group" role="group">
                        <router-link :to="{name: 'editplayer', params: { id: player.id }}" class="btn btn-primary">Edit
                        </router-link>
                       
                        <button class="btn btn-danger" @click="deletePlayer(player.id)">Delete</button>
                    </div>
                </td>
            </tr>
            

            </tbody>
        </table>
        <Pagination class="mt-6" :links="players.links" />
        <button type="button" class="btn btn-info" @click="this.$router.push('/players/add')">Add Player</button>
    </div>
</template>

<script>import axios from 'axios';
export default {

    data() {
        return {
            players: []
        }
    },
    created() {
        this.$axios.get('/sanctum/csrf-cookie').then(response => {
            this.$axios.get('/api/player')
                .then(response => {
                    console.log(response.data)
                    this.players = response.data;
                })
                .catch(function (error) {
                    console.error(error);
                });
        })
    },
    methods: {
        deletePlayer(id) {
            this.$axios.get('/sanctum/csrf-cookie').then(response => {
                this.$axios.delete('/api/player/delete/${id}')
                    .then(response => {
                        let i = this.players.map(item => item.id).indexOf(id); // find index of your object
                        this.players.splice(i, 1)
                    })
                    .catch(function (error) {
                        console.error(error);
                    });
            })
        }
    },
    beforeRouteEnter(to, from, next) { console.log(window.Laravel.isLoggedin)
        if (!window.Laravel.isLoggedin) {
            window.location.href = "/";
        }
        next();
    }
}
</script>