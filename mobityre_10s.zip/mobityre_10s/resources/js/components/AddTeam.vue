<template>
    <div>
        <h4 class="text-center">Add Team</h4>
        <div class="row">
            <div class="col-md-6">
                <form @submit.prevent="addTeam">
                    <div class="form-group">
                        <label>Team Name</label>
                        <input type="text" name="tname" class="form-control" v-model="team.tname">
                    </div>
                    <div class="form-group">
                        <label>Money Balance</label>
                        <input type="text" name="mnybal" class="form-control" v-model="team.money_bal">
                    </div>
                    <button type="submit" class="btn btn-primary">Add Team</button>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            team: {}
        }
    },
    methods: {
        addTeam() {
            this.$axios.get('/sanctum/csrf-cookie').then(response => {
                this.$axios.post('/api/team/add', this.team)
                    .then(response => {
                        this.$router.push({name: 'team'})
                    })
                    .catch(function (error) {
                        console.error(error);
                    });
            })
        }
    },
    beforeRouteEnter(to, from, next) {
        if (!window.Laravel.isLoggedin) {
            window.location.href = "/";
        }
        next();
    }
}
</script>