<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Team;
use App\Models\Country;
class PlayerController extends Controller
{
     // all Player
     public function index()
     {
        $player = DB::table('players')
            ->join('countries', 'players.cntryid', '=', 'countries.id')
            ->join('teams', 'teams.teamid', '=', 'teams.id')
            ->select('players.*', 'cntryname', 'tname','money_bal')
            ->paginate(10);


         return array_reverse($player);
     }
 
     // add Player
     public function add(Request $request)
     {
         $player = new Player([
             'teamid' => $request->teamid,
             'cntryid' => $request->cntryid,
             'pfsname' => $request->pfsname,
             'pscname' => $request->pscname,
             'buyamnt' => $request->buyamnt,
             'sellamnt' => $request->sellamnt
         ]);
         $player->save();
 
         return response()->json('The Player successfully added');
     }
 
     // edit Player
     public function edit($id)
     {
         $player = Player::find($id);
         return response()->json($player);
     }
 
     // update Player
     public function update($id, Request $request)
     {
         $player = Player::find($id);
         $player->update($request->all());
         return response()->json('The Player successfully updated');
     }
 
     // delete Player
     public function delete($id)
     {
         $player = Player::find($id);
         $player->delete();
 
         return response()->json('The Player successfully deleted');
     }
}
