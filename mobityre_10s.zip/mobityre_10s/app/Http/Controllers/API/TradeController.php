<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Team;
use App\Models\Country;
use App\Models\Player;
class TradeController extends Controller
{
     // all Player
     public function index()
     {
        $player = DB::table('players')
            ->join('countries', 'players.cntryid', '=', 'countries.id')
            ->join('teams', 'teams.teamid', '=', 'teams.id')
            ->select('players.*', 'cntryname', 'tname','money_bal')
            ->paginate(10);


         return array_reverse($player);
     }

     // select player to buy Player
     public function buy($id)
     {
       
         $player = DB::table('players')
         ->join('teams', 'teams.teamid', '=', 'teams.id')
         ->select('players.*',  'tname','money_bal')
         ->where('players.id', $id)
         ->get();
         return response()->json($player);

     }
 
     // actual buying Player
     public function updatebuy($id, Request $request)
     {
        $oldteam = Team::find($request->input("oldteamId"));
        $oldbal=$oldteam->money_bal;   //get the team old balance
        if ($request->input("oldteamId")==$request->input("newteamId")) {  //if selected same team
            $success = false;
            $message = 'Choose different Team.';
        } else if($oldbal<$request->input("buyamount")){  //check sufficient fund
            $success = false;
            $message = 'You do not have Sufficient fund.';
        }else{
            $newbal=$oldbal-$request->input("buyamount");  //subtract old team balance from price of player

            $model = Player::find($id);
            $model->update(['teamid', $request->input("newteamId")]);
            $success = true;
            $message = 'The Player successfully been bought.';
        }

        // response
        $response = [
            'success' => $success,
            'message' => $message,
        ];
        
        return response()->json($response);

     }
     
     // select player to sell Player
     public function sell($id)
     {
       
         $player = DB::table('players')
         ->join('teams', 'teams.teamid', '=', 'teams.id')
         ->select('players.*',  'tname','money_bal')
         ->where('players.id', $id)
         ->get();
         return response()->json($player);

     }
 
     // actual selling Player
     public function updatesell($id, Request $request)
     {
         $oldteam = Team::find($request->input("oldteamId"));
         $oldbal=$oldteam->money_bal;                        //get the team old balance
         $newbal=$oldbal+$request->input("buyamount");  //add old team balance from price of player

         $model = Player::find($id);
         $model->update(['teamid', $request->input("newteamId")]);

 
         return response()->json('The Player successfully been sold.');
     }

}
