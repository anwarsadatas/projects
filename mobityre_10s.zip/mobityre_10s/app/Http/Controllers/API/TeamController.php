<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Team;
class TeamController extends Controller
{
     // all Team
     public function index()
     {
         $team = Team::all()->toArray();
         return array_reverse($team);
     }
 
     // add Team
     public function add(Request $request)
     {
        $id = auth()->user()->id;       // get user id
        $userId = Team::select('userId') // check if same user has already created a team
                           ->where('userId', '=', $id )
                           ->get();   
        if($id==$userId){
            return response()->json('You already have a team.');
        }else{
        
            $team = new Team([
            'userId' => $id,
             'tname' => $request->tname,
             'money_bal' => $request->mnybal
            ]);
             $team->save();
         return response()->json('The Team successfully added');
        }
     }
 
     // edit Team
     public function edit($id)
     {
         $team = Team::find($id);
         return response()->json($team);
     }
 
     // update Team
     public function update($id, Request $request)
     {
         $team = Team::find($id);
         $team->update($request->all());
 
         return response()->json('The Team successfully updated');
     }
 
     // delete Team
     public function delete($id)
     {
         $team = Team::find($id);
         $team->delete();
 
         return response()->json('The Team successfully deleted');
     }   
     
     public function getTeams()
     {
         $data = Team::get();
    
         return response()->json($data);
     }


}
