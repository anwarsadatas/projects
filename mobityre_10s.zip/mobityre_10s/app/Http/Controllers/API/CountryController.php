<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Country;
class CountryController extends Controller
{
    public function getCountries()
    {
        $data = Country::get();
   
        return response()->json($data);
    }
}
