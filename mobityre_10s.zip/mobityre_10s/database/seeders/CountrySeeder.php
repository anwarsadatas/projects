<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CountrySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $data = [
            [
                'cntryname' => 'Kenya',
            ],
            [
                'cntryname' => 'Uganda',
            ],
            [
                'cntryname' => 'Tanzania',
            ],
            [
                'cntryname' => 'Rwanda',
            ],
            [
                'cntryname' => 'Bostwana',
            ],
            [
                'cntryname' => 'Jamaica',
            ],
            [
                'cntryname' => 'Zambia',
            ],
        ];
        Country::insert($data);
    }
}
